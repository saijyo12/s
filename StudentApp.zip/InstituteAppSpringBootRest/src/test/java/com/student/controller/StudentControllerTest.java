package com.student.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.DefaultMockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.student.service.StudentService;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@WebAppConfiguration
@ContextConfiguration(classes = StudentController.class)
class StudentControllerTest {
	@InjectMocks
	private StudentController studentController;
	@Mock
	StudentService service;

	@Autowired
	private WebApplicationContext context;
	private MockMvc mockMVC;

	@Before
	public void setup() throws Exception {
		MockitoAnnotations.initMocks(this);
		DefaultMockMvcBuilder builder = MockMvcBuilders.webAppContextSetup(this.context);
		this.mockMVC = builder.build();
	}

	/*
	 * @Test void testSetStudentService() {
	 * 
	 * }
	 */
	@Test
	void testAddStudent() throws Exception {
		ResultMatcher ok = MockMvcResultMatchers.status().isOk();
		MockMultipartFile file = new MockMultipartFile("student-file", "Student.xlsx", "application/vnd.ms-excel",
				"test data".getBytes());
		MockHttpServletRequestBuilder mockBuilder = MockMvcRequestBuilders.fileUpload("/students/studentsdata")
				.file(file);
		// this.mockMVC.perform(mockBuilder).andExpect(ok).andDo(MockMvcResultHandlers.print());

		assertEquals(false, file.isEmpty());
		String driverPath = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", driverPath + "/drivers/ChromeDriver/chromedriver.exe");

		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability("marionette", true);
		WebDriver driver = new ChromeDriver(capabilities);
		driver.get("http://localhost:8080/swagger-ui.html#/student-controller");
		driver.findElement(By.id("1")).sendKeys("C:\\Users\\Karnati.jyothsna\\Downloads\\JavaProjects\\Student.xlsx");
		
		// String checkText = driver.findElement(By.id("returnMessage")).getText();
		// assertEquals("", "");
	}

	/*
	 * @Test void testGetStudents() { Student student = new Student(); List<Student>
	 * sts = new ArrayList<>(); sts = service.getAllStudentData(); //
	 * assertEquals(service.getAllStudentData(), sts); }
	 */

	@Test
	void testGetStudentById() {
	}

	@Test
	void testUpdateStudent() {
	}

	@Test
	void testDeleteStudent() {
	}

}
