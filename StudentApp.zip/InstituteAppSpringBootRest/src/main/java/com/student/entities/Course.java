package com.student.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "Course")
public class Course {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "course_seq")
	@SequenceGenerator(name = "course_seq", sequenceName = "course_sequence", initialValue = 1, allocationSize = 1)
	private Long courseId;
	@Column
	private String courseName;

	@ManyToMany(mappedBy = "courses")
	private Set<Student> students = new HashSet<>();

	@ManyToMany
	@JoinTable(name = "COURSE_GUIDES", joinColumns = @JoinColumn(name = "courseId", referencedColumnName = "courseId"), inverseJoinColumns = @JoinColumn(name = "guideId", referencedColumnName = "guideId"))
	private Set<Guide> guides = new HashSet<>();

}
