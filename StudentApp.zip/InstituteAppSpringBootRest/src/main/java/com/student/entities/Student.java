package com.student.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

/*@Entity annotation to make class as Entity class
@Table(name="student") to create a table with specified name(student)*/
@Entity
@Data
@Table(name = "student")
@EntityListeners(AuditingEntityListener.class)
public class Student {

	/*
	 * @Id annotation to make id column as primarykey and
	 * 
	 * @GeneratedValue(strategy = GenerationType.AUTO) to auto increament id value
	 * when ever new record inserted,@column to make properties as column in DB
	 * and @NotBlank is make column as not tobe blank
	 */

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "student_seq")
	@SequenceGenerator(name = "student_seq", sequenceName = "student_sequence", initialValue = 1, allocationSize = 1)
	private long id;

	@Column
	private String name;
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "id")
	@JoinTable(name = "Student_Address", joinColumns = @JoinColumn(name = "sid", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "aid", referencedColumnName = "id"))
	@JsonIgnore
	private Set<Address> address;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "id")
	@JoinTable(name = "STUDENT_COURSES", joinColumns = @JoinColumn(name = "studentId", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "courseId", referencedColumnName = "courseId"))
	@JsonIgnore
	private Set<Course> courses = new HashSet<>();

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "id")
	@JoinTable(name = "STUDENT_GUIDES", joinColumns = @JoinColumn(name = "studentId", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "guideId", referencedColumnName = "guideId"))
	@JsonIgnore
	private Set<Guide> guides = new HashSet<>();
}
