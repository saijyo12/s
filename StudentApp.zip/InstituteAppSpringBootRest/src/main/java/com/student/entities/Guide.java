package com.student.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "Guide")
public class Guide {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Guide_seq")
	@SequenceGenerator(name = "Guide_seq", sequenceName = "Guide_sequence", initialValue = 1, allocationSize = 1)
	private Long guideId;
	@Column
	private String guideName;

	@ManyToMany(mappedBy = "guides")
	private Set<Student> students = new HashSet<>();

	@ManyToMany(mappedBy = "guides")
	private Set<Course> courses = new HashSet<>();
}
