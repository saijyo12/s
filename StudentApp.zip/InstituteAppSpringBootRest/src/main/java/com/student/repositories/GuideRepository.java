package com.student.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.student.entities.Guide;

public interface GuideRepository extends JpaRepository<Guide, Long> {

}
