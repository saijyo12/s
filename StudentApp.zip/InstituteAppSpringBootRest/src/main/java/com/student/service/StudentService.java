package com.student.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.student.entities.Student;

//create student service to insert,delete,update,retrieve data into course table
//@Service Indicates that an annotated class is a "Service"
@Service
public interface StudentService {
	public String addStudent(MultipartFile file);

	public List<Student> getAllStudentData();

	public List<Student> findStudentByid(Long id);

	public void deleteStudentDataById(Long id);

	public Student updateStudentById(Long id, Student stDetails);

}
