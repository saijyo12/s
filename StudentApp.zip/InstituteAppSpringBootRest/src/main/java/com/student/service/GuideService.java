package com.student.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.student.entities.Guide;

//create guide service to insert,delete,update,retrieve data into course table
//@Service Indicates that an annotated class is a "Service"
@Service
public interface GuideService {
	public Guide saveGuideData(Guide guide);

	public List<Guide> getAllGuides();

	public List<Guide> findGuideByid(Long id);

	public void deleteGuideDataById(Long id);

	public Guide updateGuideById(Long id, Guide guideDetails);

}
