package com.student.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.student.entities.Address;
import com.student.entities.Course;
import com.student.entities.Guide;
import com.student.entities.Student;
import com.student.repositories.AddressRepository;
import com.student.repositories.StudentRepository;
import com.studentfile.exception.FileStorageException;

//create student serviceImpl to insert,delete,update,retrieve data into student table
//@Service Indicates that an annotated class is a "Service"
@Service
@Component
public class StudentServiceImpl implements StudentService {
	/*
	 * @Autowired Marks a constructor or field or setter method as to be autowired
	 * by Spring's dependency injection facilities. Autowire studentRepository and
	 * AddressRepository to do crudOperations on entity
	 */

	@Autowired
	private StudentRepository studentRepository;
	@Autowired
	private AddressRepository addressRepository;

	public void setStudentRepository(StudentRepository studentRepository) {
		this.studentRepository = studentRepository;
	}

	// create Logger to display content on the console
	org.slf4j.Logger log = LoggerFactory.getLogger(this.getClass().getName());

	// to insert or add and save student data into student table using JpaRepository
	// save()
	public String addStudent(MultipartFile file) {
		Student studentDetails = new Student();
		List<Student> studentlst = new ArrayList<>();
		Set<Address> addressSet = new HashSet<>();
		Set<Course> courseSet = new HashSet<>();
		Set<Guide> guideSet = new HashSet<>();
		LinkedHashMap<Integer, String> map = new LinkedHashMap<Integer, String>();
		Address address = new Address();
		Course course = new Course();
		Guide guide = new Guide();
		try {
			// read excel data using apache poi
			String fileName = file.getOriginalFilename();
			try {
				// Check if the file's name contains invalid characters
				if (fileName.contains("..")) {
					throw new FileStorageException("invalid filename" + fileName);
				}

			} catch (Exception e) {
				// e.printStackTrace();
				log.error(e.getMessage());
			}
			// Create an excel workbook from the file system

			Workbook workbook;
			if (fileName.endsWith(".xlsx")) {
				workbook = new XSSFWorkbook(file.getInputStream());
			} else {
				workbook = new HSSFWorkbook(file.getInputStream());
			}
			// Get the first sheet on the workbook.
			Sheet sheet = workbook.getSheetAt(0);
			@SuppressWarnings("rawtypes")
			Iterator rows = sheet.rowIterator();
			long adrressId = 0;
			while (rows.hasNext()) {
				XSSFRow row = (XSSFRow) rows.next();
				// Retrieve all the rows excluding 0th row i.e., header row
				if (row.getRowNum() > 0) {
					@SuppressWarnings("rawtypes")
					Iterator cells = row.cellIterator();
					// iterate each cell and put it in a map with columnIndex
					while (cells.hasNext()) {
						XSSFCell cell = (XSSFCell) cells.next();
						cell.setCellType(Cell.CELL_TYPE_STRING);
						map.put(cell.getColumnIndex(), cell.getStringCellValue());
					} // CellIterator End
					// iterate map to set student details
					Set<Entry<Integer, String>> st = map.entrySet();
					for (Map.Entry<Integer, String> me : st) {
						if (me.getKey() == 0) {
							studentDetails.setId(Long.parseLong(me.getValue()));
						} else if (me.getKey() == 1) {
							studentDetails.setName(me.getValue().toString());
						} else if (me.getKey() == 2) {
							address.setId(adrressId);
							address.setCity((String) me.getValue());
							addressSet.add(address);
							// save address data,course data and guide data before storing into student
							// table
							addressRepository.save(address);
							course.setCourseId((long) 22);
							courseSet.add(course);
							guide.setGuideId((long) 47);
							guideSet.add(guide);
							studentDetails.setAddress(addressSet);
							studentDetails.setCourses(courseSet);
							studentDetails.setGuides(guideSet);
						}
					} // mapIterator End
					studentlst.add(studentDetails);
					log.info("Adding Student...." + studentDetails);
					studentRepository.save(studentDetails);

				} // if RowNum>0 End
				adrressId++;
			} // RowIterator End
		} catch (Exception e) {
			e.printStackTrace();
			log.info("Please try Again!");
			return "Invalid file....Please try Again!";
		}
		return "Students Record saved Successfully!";

	}

	// to get or retrieve student data from student table using findAll() of
	// JpaRepository
	public List<Student> getAllStudentData() {
		return (List<Student>) studentRepository.findAll();
	}
	// get student data based on studentId
	// to find student data based on id from student table using findById() of
	// JpaRepository

	public List<Student> findStudentByid(Long id) {
		List<Student> studentdata = new ArrayList<>();
		studentdata.add(studentRepository.findById(id).get());
		return studentdata;
	}

	// to delete student data based on id from student table using delete() of
	// JpaRepository
	@SuppressWarnings("static-access")
	public void deleteStudentDataById(Long id) {
		try {
			Optional<Student> student = studentRepository.findById(id);
			if (student.isPresent()) {
				Student student1 = student.get();
				studentRepository.delete(student1);
			} else {
				throw new Exception("Please try Again!");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// to update student data based on id of student table using JpaRepository
	// save()
	public Student updateStudentById(Long id, Student stDetails) {
		// TODO Auto-generated method stub
		Optional<Student> student = studentRepository.findById(id);
		if (student.isPresent()) {
			Student student1 = student.get();
			student1.setName(stDetails.getName());
			student1.setAddress(stDetails.getAddress());
			studentRepository.save(student1);
		}
		return stDetails;

	}

}
