package com.student.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.student.entities.Course;
//create course service to insert,delete,update,retrieve data into course table
//@Service Indicates that an annotated class is a "Service"
@Service
public interface CourseService {
	
	public Course saveCourse(Course course);
	public List<Course> getAllCourses();
	public List<Course> findCourseByid(Long id);
	public void deleteCourseDataById(Long id);
	public Course updateCourseById(Long id, Course courseDetails);

}
