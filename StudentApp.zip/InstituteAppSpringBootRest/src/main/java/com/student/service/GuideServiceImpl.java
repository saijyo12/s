package com.student.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.entities.Course;
import com.student.entities.Guide;
import com.student.repositories.GuideRepository;

//create guide serviceImpl to insert,delete,update,retrieve data into course table
//@Service Indicates that an annotated class is a "Service"
@Service
public class GuideServiceImpl implements GuideService {
	/*
	 * @Autowired Marks a constructor or field or setter method as to be autowired
	 * by Spring's dependency injection facilities. Autowire courseRepository to do
	 * crudOperations on entity
	 */
	@Autowired
	GuideRepository guideRepository;

	// to insert or add and save guides data into guide table using JpaRepository
	// save()
	public Guide saveGuideData(Guide guide) {
		Guide guideDetails = new Guide();
		guideDetails.setGuideId(guide.getGuideId());
		guideDetails.setGuideName(guide.getGuideName());
		return guideRepository.save(guide);
	}

	// to get or retrieve guides data from guide table using findAll() of
	// JpaRepository
	public List<Guide> getAllGuides() {
		return (List<Guide>) guideRepository.findAll();
	}

	// to find Guide data based on id from Guide table using findById() of
	// JpaRepository
	public List<Guide> findGuideByid(Long id) {
		List<Guide> guidedata = new ArrayList<>();
		guidedata.add(guideRepository.findById(id).get());
		return guidedata;
	}

	// to delete Guide data based on id from Guide table using delete() of
	// JpaRepository
	public void deleteGuideDataById(Long id) {
		Optional<Guide> guide = guideRepository.findById(id);
		if (guide.isPresent()) {
			Guide Guide1 = guide.get();
			guideRepository.delete(Guide1);
		}
	}

	// to update Guide data based on id of Guide table using JpaRepository
	// save()
	public Guide updateGuideById(Long id, Guide guideDetails) {
		// TODO Auto-generated method stub
		Optional<Guide> guide = guideRepository.findById(id);
		if (guide.isPresent()) {
			Guide guide1 = guide.get();
			guide1.setGuideName(guideDetails.getGuideName());
			guideRepository.save(guide1);
		}
		return guideDetails;

	}

}
