package com.student.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.entities.Course;
import com.student.entities.Guide;
import com.student.entities.Student;
import com.student.repositories.CourseRepository;

//create student service to insert,delete,update,retrieve data into course table
//@Service Indicates that an annotated class is a "Service"
@Service
public class CourseServiceImpl implements CourseService {
	/*
	 * @Autowired Marks a constructor or field or setter method as to be autowired
	 * by Spring's dependency injection facilities. Autowire courseRepository to do
	 * crudOperations on entity
	 */
	@Autowired
	CourseRepository courseRepository;

	// to insert or add and save course data into course table using JpaRepository
	// save()
	@Override
	public Course saveCourse(Course course) {
		try {
			Course courseDetails = new Course();
			courseDetails.setCourseId(course.getCourseId());
			courseDetails.setCourseName(course.getCourseName());
			return courseRepository.save(course);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return course;
	}

	// to get or retrieve courses data from course table using findAll() of
	// JpaRepository
	public List<Course> getAllCourses() {
		return (List<Course>) courseRepository.findAll();
	}

	// to find course data based on id from course table using findById() of
	// JpaRepository
	public List<Course> findCourseByid(Long id) {
		List<Course> coursedata = new ArrayList<>();
		coursedata.add(courseRepository.findById(id).get());
		return coursedata;
	}

	// to update course data based on id of course table using JpaRepository
	// save()
	public Course updateCourseById(Long id, Course courseDetails) {
		// TODO Auto-generated method stub
		Optional<Course> course = courseRepository.findById(id);
		if (course.isPresent()) {
			Course course1 = course.get();
			course1.setCourseName(courseDetails.getCourseName());
			courseRepository.save(course1);
		}
		return courseDetails;

	}

	// to delete course from course table based on courseId from course table using
	// JpaRepository
	// delete()
	public void deleteCourseDataById(Long id) {
		Optional<Course> course = courseRepository.findById(id);
		if (course.isPresent()) {
			Course course1 = course.get();
			courseRepository.delete(course1);
		}
	}
}
