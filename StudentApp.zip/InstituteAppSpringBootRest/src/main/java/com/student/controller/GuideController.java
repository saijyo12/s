package com.student.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.student.entities.Guide;
import com.student.service.GuideService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/*It includes the @Controller and @ResponseBody annotations 
 * used to simplifies the controller implementation
 */
@RestController
@RequestMapping("/students")
@Api(value = "Guide Record", description = "it shows Guide information")

public class GuideController {
	/*
	 * @Autowired Marks a constructor or field or setter method as to be autowired
	 * by Spring's dependency injection facilities.
	 */
	@Autowired
	GuideService guideService;

	// add or save guides
	// @POSTMapping to insert and save data into database
	// @RequestBody Annotation indicating a method parameter should be bound to the
	// body of the web request
	@PostMapping("/Guidedata")
	public Guide addGuide(@RequestBody Guide Guide) {
		return guideService.saveGuideData(Guide);
	}

	/*
	 * get or retrieve All guides data
	 * 
	 * @GetMapping Annotation for mapping HTTP GET requests onto specific handler
	 * methods. Specifically, @GetMapping is a composed annotation that acts as a
	 * shortcut for @RequestMapping(method = RequestMethod.GET).
	 */
	@ApiOperation(value = "Returns List of All Guides")
	@ApiResponses(value = { @ApiResponse(code = 100, message = "some message") })
	@GetMapping("/Guide")
	public List<Guide> getGuides() {
		return guideService.getAllGuides();
	}

	/*
	 * get or retrieve Guide data by id
	 * 
	 * @GetMapping Annotation for mapping HTTP GET requests onto specific handler
	 * methods. Specifically, @GetMapping is a composed annotation that acts as a
	 * shortcut for @RequestMapping(method = RequestMethod.GET).
	 */
	@ApiOperation(value = "Returns Guide data based on id")
	@GetMapping("/Guide/{id}")
	public ResponseEntity<List<Guide>> getGuideById(@PathVariable(value = "id") Long guideId) {
		List<Guide> guide = guideService.findGuideByid(guideId);
		if (guide == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok().body(guide);
	}

	/*
	 * update Guide by id using @PutMapping Annotation for mapping HTTP PUT requests
	 * onto specific handler methods. Specifically, it is a composed annotation that
	 * acts as a shortcut for @RequestMapping(method = RequestMethod.PUT).
	 */
	@ApiOperation(value = "Returns updated Guide data based on id")
	@PutMapping("/Guide/{id}")
	public ResponseEntity<Guide> updateGuide(@PathVariable(value = "id") Long GuideId,
			@Valid @RequestBody Guide GuideDetails) {
		Guide updatedGuide = guideService.updateGuideById(GuideId, GuideDetails);
		return ResponseEntity.ok().body(updatedGuide);
	}

	/*
	 * delete Guide data by id
	 * 
	 * @DeleteMapping Annotation for mapping HTTP DELETE requests onto specific
	 * handler methods.Specifically, it is a composed annotation that acts as a
	 * shortcut for
	 * 
	 * @RequestMapping(method = RequestMethod.DELETE).
	 */
	@ApiOperation(value = "Returns Response when a Guide deleted based on id")
	@DeleteMapping("/Guide/{id}")
	public ResponseEntity<Guide> deleteGuide(@PathVariable(value = "id") Long stId) {
		guideService.deleteGuideDataById(stId);
		return ResponseEntity.ok().build();
	}

}
