package com.student.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.student.entities.Course;
import com.student.service.CourseService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/*It includes the @Controller and @ResponseBody annotations 
 * used to simplifies the controller implementation
 */
@RestController
@RequestMapping("/students")
@Api(value = "Course Record", description = "it shows course information")

public class CourseController {

	/*
	 * @Autowired Marks a constructor or field or setter method as to be autowired
	 * by Spring's dependency injection facilities.
	 */
	@Autowired
	CourseService courseService;

	// add or save courses
	// @POSTMapping to insert and save data into database
	// @RequestBody Annotation indicating a method parameter should be bound to the
	// body of the web request
	@ApiOperation(value = "Insert or add or save course data")
	@PostMapping("/coursedata")
	public Course addCourse(@RequestBody Course course) {
		return courseService.saveCourse(course);
	}

	/*
	 * get or retrieve Course data by id
	 * 
	 * @GetMapping Annotation for mapping HTTP GET requests onto specific handler
	 * methods. Specifically, @GetMapping is a composed annotation that acts as a
	 * shortcut for @RequestMapping(method = RequestMethod.GET).
	 */
	@ApiOperation(value = "Returns List of All courses")
	@ApiResponses(value = { @ApiResponse(code = 100, message = "some message") })
	@GetMapping("/course")
	public List<Course> getcourses() {
		return courseService.getAllCourses();
	}

	/*
	 * get or retrieve Course data by id
	 * 
	 * @GetMapping Annotation for mapping HTTP GET requests onto specific handler
	 * methods. Specifically, @GetMapping is a composed annotation that acts as a
	 * shortcut for @RequestMapping(method = RequestMethod.GET).
	 */
	@ApiOperation(value = "Returns course data based on id")
	@GetMapping("/course/{id}")
	public ResponseEntity<List<Course>> getcourseById(@PathVariable(value = "id") Long courseId) {
		List<Course> course = courseService.findCourseByid(courseId);
		if (course == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok().body(course);
	}

	/*
	 * update course by id using @PutMapping Annotation for mapping HTTP PUT
	 * requests onto specific handler methods. Specifically, it is a composed
	 * annotation that acts as a shortcut for @RequestMapping(method =
	 * RequestMethod.PUT).
	 */
	@ApiOperation(value = "Returns updated course data based on id")
	@PutMapping("/course/{id}")
	public ResponseEntity<Course> updatecourse(@PathVariable(value = "id") Long courseId,
			@Valid @RequestBody Course courseDetails) {
		Course updatedCourse = courseService.updateCourseById(courseId, courseDetails);
		return ResponseEntity.ok().body(updatedCourse);
	}

	/*
	 * delete course data by id using
	 * 
	 * @DeleteMapping Annotation for mapping HTTP DELETE requests onto specific
	 * handler methods.Specifically, it is a composed annotation that acts as a
	 * shortcut for
	 * 
	 * @RequestMapping(method = RequestMethod.DELETE).
	 */
	@ApiOperation(value = "Returns Response when a course deleted based on id")
	@DeleteMapping("/course/{id}")
	public ResponseEntity<Course> deletecourse(@PathVariable(value = "id") Long stId) {
		courseService.deleteCourseDataById(stId);
		return ResponseEntity.ok().build();
	}

}
