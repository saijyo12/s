package com.student.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.student.entities.Student;
import com.student.service.StudentService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/*It includes the @Controller and @ResponseBody annotations 
 * used to simplifies the controller implementation
 */
@RestController
@RequestMapping("/students")
@Api(value = "Student Record", description = "it shows students information")
public class StudentController {

	/*
	 * @Autowired Marks a constructor or field or setter method as to be autowired
	 * by Spring's dependency injection facilities.
	 */
	@Autowired
	StudentService studentService;

	public void setStudentService(StudentService studentService) {
		this.studentService = studentService;
	}

	// insert or add or save student data into database by calling
	// addStudent(multipartfile) from service
	// @POSTMapping to insert and save data into database
	// @RequestBody Annotation indicating a method parameter should be bound to the
	// body of the web request
	@ApiOperation(value = "Returns Response after adding student data")
	@PostMapping("/studentsdata")
	public String addStudent(@Valid @RequestParam MultipartFile file) {
		System.out.println(file.getOriginalFilename());
		return studentService.addStudent(file);
	}

	/*
	 * get All students data
	 * 
	 * @GetMapping Annotation for mapping HTTP GET requests onto specific handler
	 * methods. Specifically, @GetMapping is a composed annotation that acts as a
	 * shortcut for @RequestMapping(method = RequestMethod.GET).
	 */
	@ApiOperation(value = "Returns List of All students")
	@ApiResponses(value = { @ApiResponse(code = 100, message = "some message") })
	@GetMapping("/student")
	public List<Student> getStudents() {
		return studentService.getAllStudentData();
	}

	/*
	 * // get student by id
	 * 
	 * @GetMapping Annotation for mapping HTTP GET requests onto specific handler
	 * methods. Specifically, @GetMapping is a composed annotation that acts as a
	 * shortcut for @RequestMapping(method = RequestMethod.GET).
	 */
	@ApiOperation(value = "Returns Student data based on id")
	@GetMapping("/student/{id}")
	public ResponseEntity<List<Student>> getStudentById(@PathVariable(value = "id") Long stId) {
		List<Student> student = studentService.findStudentByid(stId);
		if (student == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok().body(student);
	}

	/*
	 * update student by id using @PutMapping Annotation for mapping HTTP PUT
	 * requests onto specific handler methods. Specifically, it is a composed
	 * annotation that acts as a shortcut for @RequestMapping(method =
	 * RequestMethod.PUT).
	 */
	@ApiOperation(value = "Returns updated Student data based on id")
	@PutMapping("/student/{id}")
	public ResponseEntity<Student> updateStudent(@PathVariable(value = "id") Long stId,
			@Valid @RequestBody Student stDetails) {
		Student updatedStudent = studentService.updateStudentById(stId, stDetails);
		return ResponseEntity.ok().body(updatedStudent);
	}

	/*
	 * delete student data by id using
	 * 
	 * @DeleteMapping Annotation for mapping HTTP DELETE requests onto specific
	 * handler methods.Specifically, it is a composed annotation that acts as a
	 * shortcut for
	 * 
	 * @RequestMapping(method = RequestMethod.DELETE).
	 * 
	 * 
	 */
	@ApiOperation(value = "Returns Response when a student deleted based on id")
	@DeleteMapping("/student/{id}")
	public ResponseEntity<Student> deleteStudent(@PathVariable(value = "id") Long stId) {
		studentService.deleteStudentDataById(stId);
		return ResponseEntity.ok().build();
	}

}
