package com.onlineorder.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

@Entity
//@NamedQuery(name = "Order.findByProductName", query = "SELECT o FROM Order o WHERE LOWER(p.productName") 
@Data
public class OrderOnline implements Serializable {
	@Id
	@Column(name = "orderid")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long orderId;

	@Column(name = "userid")
	private Integer UserId;

	@Column(name = "productname")
	private String productName;
	@Column(name = "status")
	private String status;

	@Column(name = "price")
	private Integer price;

	@Column(name = "createdate")
	@CreationTimestamp
	private Date createdAt;
	@Column(name = "updatedate")
	@UpdateTimestamp
	private Date updatedAt;
}
