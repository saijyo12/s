package com.onlineorder.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineorder.entity.User;
import com.onlineorder.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service

@RequiredArgsConstructor
public class UserService {
	@Autowired
	UserRepository userRespository;

	public List<User> findAll() {
		return userRespository.findAll();
	}

	public Optional<User> findById(Long id) {
		return userRespository.findById(id);
	}

	public User save(User users) {
		User user=new User();
		user.setUserId(users.getUserId());
		user.setUserName(users.getUserName());
		user.setEmail(users.getEmail());
		user.setDelivery_loaction(users.getDelivery_loaction());
		user.setCreatedAt(users.getCreatedAt());
		user.setUpdatedAt(users.getUpdatedAt());
		
		return userRespository.save(user);
	}

	public void deleteById(Long id) {
		userRespository.deleteById(id);
	}
}
