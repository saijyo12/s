package com.onlineorder.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineorder.entity.OrderOnline;
import com.onlineorder.repository.OrderRepository;

@Service
public class OrderService {
	@Autowired
	OrderRepository orderRepository;

	public List<OrderOnline> findAll() {
		return orderRepository.findAll();
	}

	public Optional<OrderOnline> findById(Long id) {
		return orderRepository.findById(id);
	}
	public Optional<List<OrderOnline>> findByProductName(String productName) {
		return orderRepository.findByProductName(productName);
	}

	public OrderOnline save(OrderOnline orders) {
		OrderOnline order=new OrderOnline();
		order.setOrderId(orders.getOrderId());
		order.setProductName(orders.getProductName());
		order.setPrice(orders.getPrice());
		order.setStatus(orders.getStatus());
		order.setUserId(orders.getUserId());
		order.setCreatedAt(orders.getCreatedAt());
		order.setUpdatedAt(orders.getUpdatedAt());
		return orderRepository.save(order);
	}

	public void deleteById(Long id) {
		orderRepository.deleteById(id);
	}
}
