package com.onlineorder.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

@Entity
@Data
public class Order implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "orderid")
	private Long orderId;

	@Column(name = "userid")
	private Long UserId;

	@Column(name = "productid")
	private String productId;
	@Column(name = "status")
	private String Status;

	@Column(name = "price")
	private Double price;

	@Column(name = "createdate")
	@CreationTimestamp
	private Date createdAt;
	@Column(name = "updatedate")
	@UpdateTimestamp
	private Date updatedAt;
}
