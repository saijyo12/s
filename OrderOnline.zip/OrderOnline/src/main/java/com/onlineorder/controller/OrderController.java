package com.onlineorder.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onlineorder.entity.Order;
import com.onlineorder.service.OrderService;

import lombok.RequiredArgsConstructor;
@RestController
@RequestMapping("/api/v1/orders")
@RequiredArgsConstructor
public class OrderController {
	@Autowired
	OrderService orderService;

	@GetMapping("/getorders")
	public ResponseEntity<List<Order>> findAll() {
		return ResponseEntity.ok(orderService.findAll());
	}

	@PostMapping("/createorder")
	public ResponseEntity create(@Valid @RequestBody Order order) {
		return ResponseEntity.ok(orderService.save(order));
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<Order> findById(@PathVariable Long id) {
		Optional<Order> stock = orderService.findById(id);
		if (!stock.isPresent()) {
			// log.error("Id " + id + " is not existed");
			ResponseEntity.badRequest().build();
		}

		return ResponseEntity.ok(stock.get());
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity delete(@PathVariable Long id) {
		if (!orderService.findById(id).isPresent()) {
			// log.error("Id " + id + " is not existed");
			ResponseEntity.badRequest().build();
		}

		orderService.deleteById(id);

		return ResponseEntity.ok().build();
	}
}
