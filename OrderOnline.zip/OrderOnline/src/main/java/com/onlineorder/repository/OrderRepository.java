package com.onlineorder.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onlineorder.entity.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {

}
