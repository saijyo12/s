package com.onlineorder.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.onlineorder.entity.Order;
import com.onlineorder.entity.Product;

@Repository
public interface ProductRespository extends JpaRepository<Product, Long> {
	//@Query("SELECT o FROM Order o WHERE LOWER(o.productName) = LOWER(:productName)")
		@Query(value = "SELECT * FROM Category o WHERE o.categoryName = ?1", nativeQuery = true)
		 Optional<List<Product>> findByCategoryName(String categoryName);

}
