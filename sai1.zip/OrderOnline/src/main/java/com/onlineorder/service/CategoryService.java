package com.onlineorder.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineorder.entity.Category;
import com.onlineorder.repository.CategoryRepository;


@Service
public class CategoryService {
	@Autowired
	CategoryRepository categoryRespository;

	public List<Category> findAll() {
		return categoryRespository.findAll();
	}

	public Optional<Category> findById(Long id) {
		return categoryRespository.findById(id);
	}

	public Category save(Category category) {
		Category categories=new Category();
		categories.setCategoryId(category.getCategoryId());
		categories.setCategoryName(category.getCategoryName());
		categories.setDescription(category.getDescription());
		categories.setPrice(category.getPrice());
		categories.setCreatedAt(category.getCreatedAt());
		categories.setUpdatedAt(category.getUpdatedAt());

		return categoryRespository.save(categories);
	}

	public void deleteById(Long id) {
		categoryRespository.deleteById(id);
	}
}
