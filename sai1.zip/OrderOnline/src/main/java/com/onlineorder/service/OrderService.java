package com.onlineorder.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineorder.entity.Order;
import com.onlineorder.repository.OrderRepository;

@Service
public class OrderService {
	@Autowired
	OrderRepository orderRepository;

	public List<Order> findAll() {
		return orderRepository.findAll();
	}

	public Optional<Order> findById(Long id) {
		return orderRepository.findById(id);
	}

	public Optional<List<Order>> findByProductName(String productName) {

		return orderRepository.findByProductName(productName);
	}

	public Optional<List<Order>> findByUserName(String userName) {
		return orderRepository.findByUserName(userName);
	}

	public Order save(Order orders) {
		Order order = new Order();
		order.setOrderId(orders.getOrderId());
		order.setProductName(orders.getProductName());
		order.setPrice(orders.getPrice());
		order.setStatus(orders.getStatus());
		order.setUserId(orders.getUserId());
		order.setCreatedAt(orders.getCreatedAt());
		order.setUpdatedAt(orders.getUpdatedAt());
		return orderRepository.save(order);
	}

	public void deleteById(Long id) {
		orderRepository.deleteById(id);
	}
}
