package com.onlineorder.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.onlineorder.entity.Category;
import com.onlineorder.entity.Order;
import com.onlineorder.entity.Product;
import com.onlineorder.repository.ProductRespository;

import lombok.RequiredArgsConstructor;

@Service

@RequiredArgsConstructor
public class ProductService {
	ProductRespository productRespository;

	public List<Product> findAll() {
		return productRespository.findAll();
	}

	public Optional<Product> findById(Long id) {
		return productRespository.findById(id);
	}
	public Optional<List<Product>> findByCategoryName(String categoryName) {
		return productRespository.findByCategoryName(categoryName);
	}
 
	public Product save(Product products) {
		return productRespository.save(products);
	}

	public void deleteById(Long id) {
		productRespository.deleteById(id);
	}

	
}
