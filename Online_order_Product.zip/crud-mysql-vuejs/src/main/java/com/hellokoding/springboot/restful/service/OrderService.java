package com.hellokoding.springboot.restful.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hellokoding.springboot.entity.Order;
import com.hellokoding.springboot.restful.repository.OrderRepository;

@Service
public class OrderService {
	@Autowired
	OrderRepository orderRepository;

	public List<Order> findAll() {
		return orderRepository.findAll();
	}

	public Optional<Order> findById(Long id) {
		return orderRepository.findById(id);
	}

	public Order save(Order stock) {
		return orderRepository.save(stock);
	}

	public void deleteById(Long id) {
		orderRepository.deleteById(id);
	}
}
