package com.hellokoding.springboot.restful.service;





import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hellokoding.springboot.entity.Category;
import com.hellokoding.springboot.entity.User;
import com.hellokoding.springboot.restful.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service

@RequiredArgsConstructor
public class UserService {
	@Autowired
	UserRepository userRespository;

	public List<User> findAll() {
		return userRespository.findAll();
	}

	public Optional<User> findById(Long id) {
		return userRespository.findById(id);
	}

	public User save(User stock) {
		return userRespository.save(stock);
	}

	public void deleteById(Long id) {
		userRespository.deleteById(id);
	}
}
