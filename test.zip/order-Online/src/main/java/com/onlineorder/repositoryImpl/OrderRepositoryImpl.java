package com.onlineorder.repositoryImpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.onlineorder.entity.OrderOnline;

@Repository
public class OrderRepositoryImpl implements OrderRepositoryCustom {
	@PersistenceContext
	private EntityManager entityManager;
	@SuppressWarnings("unchecked")
	public List<OrderOnline> findByProductName(String productName) {
		return this.entityManager.createQuery("select o from ORDERONLINE o WHERE o.productName = '" + productName + "'")
				.getResultList();
	}
}