package com.onlineorder.repositoryImpl;

import java.util.List;

import com.onlineorder.entity.OrderOnline;

public interface OrderRepositoryCustom {
	public List<OrderOnline> findByProductName(String productName);

}
