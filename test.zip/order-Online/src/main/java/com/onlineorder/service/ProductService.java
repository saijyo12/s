package com.onlineorder.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineorder.entity.Product;
import com.onlineorder.repository.ProductRespository;

import lombok.RequiredArgsConstructor;

@Service

@RequiredArgsConstructor
public class ProductService {
	@Autowired
	ProductRespository productRespository;

	public List<Product> findAll() {
		return productRespository.findAll();
	}

	public Optional<Product> findById(Long id) {
		return productRespository.findById(id);
	}

	public Product save(Product products) {

		return productRespository.save(products);
	}

	 public void deleteById(Long id) {
	        productRespository.deleteById(id);
	 }

	public Product updateProductById(Long id, Product updateProduct) {
		Optional<Product> productbyid = productRespository.findById(id);
		if (productbyid.isPresent()) {
			Product product = productbyid.get();
			product.setProductName(updateProduct.getProductName());
			product.setDescription(updateProduct.getDescription());
			 productRespository.save(product);
		}
		return updateProduct;

	}
}
