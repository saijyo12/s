package com.onlineorder.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.onlineorder.entity.Product;
import com.onlineorder.repository.ProductRespository;

import lombok.RequiredArgsConstructor;

@Service

@RequiredArgsConstructor
public class ProductService {
	ProductRespository productRespository;

	public List<Product> findAll() {
		return productRespository.findAll();
	}

	public Optional<Product> findById(Long id) {
		return productRespository.findById(id);
	}

	public Product save(Product products) {
		Product product=new Product();
		product.setProductId(products.getProductId());
		product.setProductName(products.getProductName());
		product.setDescription(products.getDescription());
		product.setPrice(products.getPrice());
		product.setCreatedAt(products.getCreatedAt());
		product.setUpdatedAt(products.getUpdatedAt());
		return productRespository.save(product);
	}

	public void deleteById(Long id) {
		productRespository.deleteById(id);
	}
}
