package com.onlineorder.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.onlineorder.entity.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {
	//@Query("SELECT o FROM Order o WHERE LOWER(o.productName) = LOWER(:productName)")
	@Query(value = "SELECT * FROM ORDER o WHERE o.productName = ?1", nativeQuery = true)
	 Optional<List<Order>> findByProductName(String productName);

}
