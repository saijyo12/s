package com.onlineorder.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

@Entity
//@NamedQuery(name = "Order.findByProductName", query = "SELECT o FROM Order o WHERE LOWER(p.productName") 
@Data
public class Order implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "orderid", length = 10, precision =0)
	private Long orderId;

	@Column(name = "userid")
	private Long UserId;

	@Column(name = "productname")
	private String productName;
	@Column(name = "status")
	private String status;

	@Column(name = "price")
	private Integer price;

	@Column(name = "createdate")
	@CreationTimestamp
	private Date createdAt;
	@Column(name = "updatedate")
	@UpdateTimestamp
	private Date updatedAt;
}
