package com.onlineorder.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Entity
@Data
public class OrderOnline implements Serializable {
	@Id
	@Column(name = "orderid")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long orderId;

	@Column(name = "productname")
	private String productName;
	@Column(name = "status")
	private String status;

	@Column(name = "price")
	private Integer price;

	@Column(name = "createdate")
	@CreationTimestamp
	private Date createdAt;
	@Column(name = "updatedate")
	@UpdateTimestamp
	private Date updatedAt;
	
	@ManyToMany(cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "orderId")
	@JoinTable(name = "Order_Produts", joinColumns = @JoinColumn(name = "orderId", referencedColumnName = "orderid"), inverseJoinColumns = @JoinColumn(name = "productId", referencedColumnName = "productid"))
	@JsonIgnore
	private Set<Product> products = new HashSet<>();
	
	@ManyToMany(mappedBy = "orders")
	private Set<User> users = new HashSet<>();
}
