package com.onlineorder.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Entity
@Data
public class Product implements Serializable{

	@Id
	@Column(name = "productid")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long productId;
	
	@Column(name = "productname")
	private String productName;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "price")
	private Integer price;
	
	@Column(name = "createdate")
	@CreationTimestamp
	private Date createdAt;
	
	@Column(name = "updatedate")
	@UpdateTimestamp
	private Date updatedAt;
	
	@ManyToMany(mappedBy = "products",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<OrderOnline> orders = new HashSet<>();
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "categoryid")
	@JsonIgnore
	private Category categories;
}
