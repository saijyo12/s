package com.onlineorder.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onlineorder.entity.Category;
import com.onlineorder.service.CategoryService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/v1")
@Api(value = "Category Information", description = "it shows Category information")
public class CategoryController {
	@Autowired
	CategoryService categoryService;

	@ApiOperation(value = "Returns all Categories")
	@GetMapping("/getcategories")
	public ResponseEntity<List<Category>> findAll() {
		return ResponseEntity.ok(categoryService.findAll());
	}

	@ApiOperation(value = "add categories")
	@PostMapping("/insertcategory")
	public ResponseEntity create(@Valid @RequestBody Category Category) {
		return ResponseEntity.ok(categoryService.save(Category));
	}

	@ApiOperation(value = "delete category by id")
	@DeleteMapping("/deletecategories/{id}")
	public ResponseEntity delete(@PathVariable Long id) {
		if (!categoryService.findById(id).isPresent()) {
			ResponseEntity.badRequest().build();
		}

		categoryService.deleteById(id);

		return ResponseEntity.ok().build();
	}
}
