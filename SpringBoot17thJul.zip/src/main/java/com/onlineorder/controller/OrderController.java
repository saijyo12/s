package com.onlineorder.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onlineorder.entity.OrderOnline;
import com.onlineorder.service.OrderService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/v1")
@Api(value = "Order Information", description = "it shows order information")
public class OrderController {
	@Autowired
	OrderService orderService;

	@ApiOperation(value = "Returns all orders")
	@GetMapping("/getorders")
	public ResponseEntity<List<OrderOnline>> findAll() {
		return ResponseEntity.ok(orderService.findAll());
	}

	@ApiOperation(value = "add orders")
	@PostMapping("/createorder")
	public ResponseEntity create(@Valid @RequestBody OrderOnline order) {
		return ResponseEntity.ok(orderService.save(order));
	}

	@ApiOperation(value = "get order by order id")
	@GetMapping("/getordersbyid/{id}")
	public ResponseEntity<OrderOnline> findById(@PathVariable Long id) {
		Optional<OrderOnline> order = orderService.findById(id);
		if (!order.isPresent()) {
			ResponseEntity.badRequest().build();
		}

		return ResponseEntity.ok(order.get());
	}

	@ApiOperation(value = "get orders product name")
	@GetMapping(value = "/getordersbyproductname/{productname}")
	public ResponseEntity<List<OrderOnline>> findOrderByProductName(@PathVariable String productName) {
		List<OrderOnline> order = orderService.findByProductName(productName);
		if (!order.isEmpty()) {
			ResponseEntity.badRequest().build();
		}

		return ResponseEntity.ok(order);
	}

	@ApiOperation(value = "delete orders")
	@DeleteMapping("/deleteordersbyid/{id}")
	public ResponseEntity delete(@PathVariable Long id) {
		orderService.deleteById(id);

		return ResponseEntity.ok().build();
	}
	@ApiOperation(value = "update orders")
	@PutMapping("/updateordersbyid/{id}")
	public ResponseEntity<OrderOnline> updateOrderById(@PathVariable(value = "id") Long id,@Valid @RequestBody OrderOnline updateOrder) {
		OrderOnline updatedOrder = orderService.updateOrderById(id, updateOrder);
		return ResponseEntity.ok().body(updatedOrder);
	}
}
