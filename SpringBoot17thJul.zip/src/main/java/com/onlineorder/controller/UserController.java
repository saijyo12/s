package com.onlineorder.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onlineorder.entity.User;
import com.onlineorder.service.UserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1")
@Api(value = "User Information", description = "it shows user information")
public class UserController {
	@Autowired
	UserService UserService;

	@GetMapping("/getusers")
	@ApiOperation(value = "get All users")
	public ResponseEntity<List<User>> findAll() {
		return ResponseEntity.ok(UserService.findAll());
	}

	@PostMapping("/insertuser")
	@ApiOperation(value = "add users")
	public ResponseEntity create(@Valid @RequestBody User user) {
		return ResponseEntity.ok(UserService.save(user));
	}

	@GetMapping("/getusersbyid/{id}")
	@ApiOperation(value = "get user by id")
	public ResponseEntity<User> findById(@PathVariable Long id) {
		Optional<User> user = UserService.findById(id);
		if (!user.isPresent()) {
			ResponseEntity.badRequest().build();
		}

		return ResponseEntity.ok(user.get());
	}

	@DeleteMapping("deleteusers/{id}")
	@ApiOperation(value = "detelte user by id")
	public ResponseEntity delete(@PathVariable Long id) {
		if (!UserService.findById(id).isPresent()) {
			ResponseEntity.badRequest().build();
		}

		UserService.deleteById(id);

		return ResponseEntity.ok().build();
	}
}
