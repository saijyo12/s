package com.onlineorder.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onlineorder.entity.Product;
import com.onlineorder.service.ProductService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/v1")
@Api(value = "Product Information", description = "it shows Product information")
public class ProductController {
	@Autowired
	ProductService productService;

	@GetMapping("/getproducts")
	@ApiOperation(value = "get All products")

	public ResponseEntity<List<Product>> findAll() {
		return ResponseEntity.ok(productService.findAll());
	}

	@PostMapping("/insertproducts")
	@ApiOperation(value = "Add products")
	public ResponseEntity create(@Valid @RequestBody Product product) {
		return ResponseEntity.ok(productService.save(product));
	}

	@GetMapping("/getproductsbyid/{id}")
	@ApiOperation(value = "get products by id")

	public ResponseEntity<Product> findById(@PathVariable Long id) {
		Optional<Product> product = productService.findById(id);
		if (!product.isPresent()) {

			ResponseEntity.badRequest().build();
		}

		return ResponseEntity.ok(product.get());
	}

	@PutMapping("/updateproducts/{id}")
	@ApiOperation(value = "update products")
	public ResponseEntity<Product> updateStudentById(@PathVariable(value = "id")Long id, @Valid @RequestBody Product updateProduct) {
		Product updatedProduct = productService.updateProductById(id, updateProduct);
				return ResponseEntity.ok().body(updatedProduct);
	}

	@DeleteMapping("/deleteproduct/{id}")
	@ApiOperation(value = "delete products")

	public ResponseEntity delete(@PathVariable Long id) {
		if (!productService.findById(id).isPresent()) {

			ResponseEntity.badRequest().build();
		}

		productService.deleteById(id);

		return ResponseEntity.ok().build();
	}
}
