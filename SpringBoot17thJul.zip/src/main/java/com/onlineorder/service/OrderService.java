package com.onlineorder.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineorder.entity.OrderOnline;
import com.onlineorder.repository.OrderRepository;

@Service
public class OrderService {
	@Autowired
	OrderRepository orderRepository;

	public List<OrderOnline> findAll() {
		return (List<OrderOnline>) orderRepository.findAll();
	}

	public Optional<OrderOnline> findById(Long id) {
		return orderRepository.findById(id);
	}

	public List<OrderOnline> findByProductName(String productName) {
		return orderRepository.findByProductName(productName);
	}

	public OrderOnline save(OrderOnline orders) {
		return orderRepository.save(orders);
	}

	public void deleteById(Long id) {
		try {
			Optional<OrderOnline> order = orderRepository.findById(id);
			if (order.isPresent()) {
				OrderOnline orderdelete = order.get();
				orderRepository.delete(orderdelete);
			} else {
				throw new Exception("Please try Again!");
			}
		} catch (Exception e) {
			e.getMessage();
		}
	}

	public OrderOnline updateOrderById(Long id, OrderOnline updateOrder) {
		// TODO Auto-generated method stub
		Optional<OrderOnline> orderbyid = orderRepository.findById(id);
		if (orderbyid.isPresent()) {
			OrderOnline order = orderbyid.get();
			order.setStatus(updateOrder.getStatus());
			orderRepository.save(order);
		}
		return updateOrder;

	}
}
