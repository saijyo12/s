package com.onlineorder.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.onlineorder.entity.OrderOnline;
import com.onlineorder.repositoryImpl.OrderRepositoryCustom;
@Repository
public interface OrderRepository extends CrudRepository<OrderOnline, Long> ,OrderRepositoryCustom{
	//@Query("SELECT o FROM Order o WHERE LOWER(o.productName) = LOWER(:productName)")
	//@Query(value = "SELECT * FROM ORDERONLINE o WHERE o.productName = ?1", nativeQuery = true)
	List<OrderOnline> findByProductName(String productName);

}
